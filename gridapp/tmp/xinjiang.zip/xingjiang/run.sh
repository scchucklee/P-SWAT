#!/bin/bash
#./serial | grep BEST
#mpirun -np 10 ./ga2 | grep G 
bsub -W 00:15 -n 10 -q x64_3950dbg -o %J.out -e %J.err mpijob.openmpi /home_soft/soft/x86_64/apps/PSWAT/pswat 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 0.2 10 /home_soft/home/scliqiang/ xinjiang.out
