#!/bin/bash
./serial | grep BEST
#mpirun -np 10 ./ga2 | grep G 
